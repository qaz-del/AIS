from matplotlib import pyplot as plt
import os
import numpy as np
import pandas as pd
from datetime import *

from sqlalchemy import true
def readDir(dirPath):
    if dirPath[-1] == '/':
        print ('文件夹路径末尾不能加/')
        return
    allFiles = []
    if os.path.isdir(dirPath):
        fileList = os.listdir(dirPath)
        for f in fileList:
            f = dirPath+'/'+f
            if os.path.isdir(f):
                subFiles = readDir(f)
                allFiles = subFiles + allFiles #合并当前目录与子目录的所有文件路径
            else:
                allFiles.append(f)
        return allFiles
    else:
        return 'Error,not a dir'

def timecompare(t1,t2):# t1>t2返回true
    return time.mktime(t1)-time.mktime(t2)

def ps(lon,lat):
    '''lon_edge_1=114.28334
    lat_edge_1=30.55232
    lon_edge_2=114.293
    lat_edge_2=30.547
    A=lat_edge_1-lat_edge_2
    B=lon_edge_2-lon-lon_edge_1
    C=lon_edge_1*lat_edge_2-lon_edge_2*lat_edge_1
    if (A*lon+B*lat+C)*(A*lon_pre+B*lat_pre+C)<0 :return True
    else :return False'''
    if abs(lon-114.294)<0.02 and abs(lat-30.552)<0.01:
        return True
    else :return False
fileset=readDir('D:\\数模选拔\\data')
timetable={1:0,2:0,3:0,4:0,5:0,6:0,7:0,8:0,9:0,10:0,11:0,12:0,13:0,14:0,15:0,16:0,17:0,18:0,19:0,20:0,21:0,22:0,23:0,0:0}
for file in fileset:
    data=pd.read_csv(file,sep='\\s+',header=None)
    time=data.loc[:,1]
    lon_now=data.loc[:,3]
    lat_now=data.loc[:,4]
    lon_pre=data.loc[:,5]
    lat_pre=data.loc[:,6]
    t=[]
    for i in time:
        t.append(datetime.strptime(i ,"%H:%M:%S"))
    for i in range(len(time)):
        if ps(lon_now[i],lat_now[i]):
            timetable[t[i].time().hour]+=1
            continue
print(timetable)
plt.figure()
plt.plot(timetable.keys(),timetable.values())
